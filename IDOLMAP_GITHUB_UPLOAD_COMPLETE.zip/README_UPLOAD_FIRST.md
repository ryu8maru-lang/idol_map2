# IDOLMAP 完全復旧セット（300組表示 / HQ100）

## GitHub のルート直下に置く必須ファイル
- index.html
- styles.css
- app.js
- data.json  ← 既存リポジトリにある300組の母体をそのまま残す
- hq56.json

## データ仕様
- 表示総数: 300組
- 高精度: 100組
  - data.json 内の既存HQ44
  - hq56.json の追加HQ56
- 通常精度: 残り200組

## 重要
現在の GitHub には index.html が無いため、ページが表示されない状態になっています。
このセットの index.html / styles.css / app.js / hq56.json をアップロードしてください。
data.json は現在 GitHub にあるものを削除せず、そのまま残してください。

## GitHub Pages
Settings → Pages → Deploy from a branch
Branch: main / (root)
にしてください。

## 任意のバックアップ・編集用
- idol-map-hq-56-extension.csv
- idol-map-hq-56-extension.xlsx
