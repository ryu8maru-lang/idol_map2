const HQ44_NAMES = new Set(["乃木坂46", "=LOVE", "iLiFE!", "櫻坂46", "ももいろクローバーZ", "超ときめき♡宣伝部", "≠ME", "日向坂46", "のんふぃく！", "私立恵比寿中学", "≒JOY", "いぎなり東北産", "夜光性アミューズ", "ドレスコード", "MEGAFON", "iON!", "ばってん少女隊", "フルコース", "ラストシーン", "GILTY x GILTY", "i-COL", "AdamLilith", "TENRIN", "LADYBABY", "chuLa", "アキシブproject", "パラディーク", "Ill", "MISS MERCY", "テンシンランマン", "ナナコロビヤオキ", "ZUTTOMOTTO", "ハルカエコー", "Pastel Closet", "RE-GE", "パラレルサイダー", "ポンコツコンポ", "CAL&RES", "AMEFURASSHI", "ukka", "スタプラ研究生", "ヒロインズ研究生", "ヒロインズ研究生大阪", "浪江女子発組合"]);
async function loadHQ300(){
  const [base, extra] = await Promise.all([
    fetch('./data.json').then(r=>{if(!r.ok)throw new Error(`data.json HTTP ${r.status}`);return r.json();}),
    fetch('./hq56.json').then(r=>{if(!r.ok)throw new Error(`hq56.json HTTP ${r.status}`);return r.json();})
  ]);

  const groups = [...(base.groups || [])];
  const originalCount = groups.length;

  // 2026-08-26時点で活動終了済みの旧枠を、現役の高精度対象へ置換。
  // これにより元DBの総グループ数を増減させない。
  const replacementSlots = {
    'AsIs': 'ASP',
    'Palette Parade': 'BiTE A SHOCK',
    'きゅるりんってしてみて': '#ババババンビ',
    'Merry BAD TUNE.': '#2i2',
    'NANIMONO': '東京女子流'
  };

  let indexByName = new Map(groups.map((g,i)=>[g.name,i]));

  for (const hi of (extra.groups || [])) {
    let idx = indexByName.get(hi.name);

    if (idx === undefined && replacementSlots[hi.name]) {
      idx = indexByName.get(replacementSlots[hi.name]);
    }

    if (idx === undefined) {
      console.warn(`HQ overlay skipped to preserve ${originalCount} groups: ${hi.name}`);
      continue;
    }

    const old = groups[idx];
    const mergedMembers = (hi.members || []).map(m => {
      const oldM = (old.members || []).find(x => x.name === m.name) || {};
      return {...oldM, ...m};
    });

    groups[idx] = {
      ...old,
      ...hi,
      id: old.id || hi.id,
      members: mergedMembers.length ? mergedMembers : (old.members || [])
    };

    indexByName = new Map(groups.map((g,i)=>[g.name,i]));
  }

  if (groups.length !== originalCount) {
    throw new Error(`IDOLMAP group count changed unexpectedly: ${originalCount} -> ${groups.length}`);
  }

  for (const g of groups) {
    g.high_precision = HQ44_NAMES.has(g.name) || !!g.high_precision || String(g.verification_status||'').startsWith('verified');
  }

  return {
    ...base,
    updated: '2026-08-26',
    as_of: '2026-08-26',
    dataset: 'IDOLMAP 300 / HQ100',
    high_precision_count: 100,
    groups
  };
}

const TIER_ORDER=['SSS','SS','S','A+','A','B+','B','C','未評価'];
let DATA=null,state={tier:'ALL',faction:'ALL',q:'',sort:'tier'};
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
async function boot(){DATA=await loadHQ300();renderStats();buildFactionChips();bind();render();}
function visible(){
  let a=DATA.groups.filter(g=>
    (state.tier==='ALL'||g.tier===state.tier) &&
    (state.faction==='ALL'||g.faction===state.faction) &&
    (!state.q||(`${g.name} ${g.faction} ${g.agency||''} ${g.project||''}`).toLowerCase().includes(state.q.toLowerCase()))
  );
  return a.sort((a,b)=>
    state.sort==='power'?(b.power??-1)-(a.power??-1):
    state.sort==='growth'?(b.growth??-1)-(a.growth??-1):
    state.sort==='name'?a.name.localeCompare(b.name,'ja'):
    (TIER_ORDER.indexOf(a.tier)-TIER_ORDER.indexOf(b.tier)||(b.power??-1)-(a.power??-1))
  );
}
function renderStats(){const gs=DATA.groups;$('#groupCount').textContent=gs.length;$('#memberCount').textContent=gs.reduce((s,g)=>s+(g.members?.filter(m=>m.status!=='former').length||0),0);$('#sssCount').textContent=gs.filter(g=>g.tier==='SSS').length;$('#verifiedDate').textContent=DATA.as_of;}
function buildFactionChips(){const fs=['ALL',...new Set(DATA.groups.map(g=>g.faction))];$('#factionChips').innerHTML=fs.map(f=>`<button class="chip factionChip ${f==='ALL'?'active':''}" data-faction="${esc(f)}">${f==='ALL'?'全勢力':esc(f)}</button>`).join('');}
function bind(){$$('.tierChip').forEach(b=>b.onclick=()=>{state.tier=b.dataset.tier;$$('.tierChip').forEach(x=>x.classList.toggle('active',x===b));render();});$('#factionChips').onclick=e=>{const b=e.target.closest('button');if(!b)return;state.faction=b.dataset.faction;$$('.factionChip').forEach(x=>x.classList.toggle('active',x===b));render();};$('#search').oninput=e=>{state.q=e.target.value;render();};$('#sort').onchange=e=>{state.sort=e.target.value;render();};$('#shade').onclick=closeDrawer;$('#closeDrawer').onclick=closeDrawer;document.addEventListener('keydown',e=>{if(e.key==='Escape')closeDrawer()});}
function render(){const gs=visible();$('#resultCount').textContent=`${gs.length} groups`;const tiers=state.tier==='ALL'?TIER_ORDER:[state.tier];let html='';for(const t of tiers){const arr=gs.filter(g=>g.tier===t);if(!arr.length)continue;html+=`<div class="tierLane"><div class="laneHead"><div class="tierBadge" data-tier="${esc(t)}">${esc(t)}</div><span>${arr.length} groups</span></div><div class="cards">${arr.map(card).join('')}</div></div>`;}$('#tierMap').innerHTML=html||'<div class="empty">条件に一致するグループがありません。</div>';$$('.card').forEach(c=>c.onclick=()=>openDrawer(c.dataset.id));renderRanking(gs);}
function card(g){return `<article class="card ${g.high_precision?'hq':''}" data-id="${esc(g.id)}"><div class="cardTop"><div><div class="faction">${esc(g.faction)}</div><h3>${esc(g.name)}</h3></div><span class="miniTier">${esc(g.tier)}</span></div><div class="meters"><div class="meter"><small>POWER</small><b>${g.power??'—'}</b></div><div class="meter"><small>GROWTH</small><b>${g.growth??'—'}</b></div></div><div class="live">${esc(g.live_scale||'ライブ規模：未確認')}</div></article>`;}
function renderRanking(gs){const a=[...gs].sort((a,b)=>(b.power??-1)-(a.power??-1)||(b.growth??-1)-(a.growth??-1));$('#rankingBody').innerHTML=a.map((g,i)=>`<tr><td class="rankNum">${i+1}</td><td><b>${esc(g.name)}</b><br><small>${esc(g.faction)}</small></td><td>${esc(g.tier)}</td><td>${g.power??'—'}</td><td>${g.growth??'—'}</td><td>${esc(g.live_scale||'未確認')}</td></tr>`).join('');}
function openDrawer(id){const g=DATA.groups.find(x=>x.id===id);if(!g)return;$('#drawer').classList.add('open');const links=[['公式HP',g.official_hp],['X',g.x],['Instagram',g.instagram],['TikTok',g.tiktok],['YouTube',g.youtube]];const members=g.members||[];$('#drawerContent').innerHTML=`<button class="close" id="innerClose">×</button><div class="detailHero"><div class="faction">${esc(g.faction)}</div><h2>${esc(g.name)}</h2><div class="scorePills"><span class="scorePill">TIER ${esc(g.tier)}</span><span class="scorePill">POWER ${g.power??'未評価'}</span><span class="scorePill">GROWTH ${g.growth??'未評価'}</span></div></div><div class="detailGrid"><div class="detail"><small>デビュー日</small><b>${esc(g.debut_date||'未確認')}</b></div><div class="detail"><small>所属・運営</small><b>${esc(g.agency||'未確認')}</b></div><div class="detail"><small>プロジェクト</small><b>${esc(g.project||'未確認')}</b></div><div class="detail"><small>レーベル</small><b>${esc(g.label||'未確認')}</b></div><div class="detail" style="grid-column:1/-1"><small>ライブ規模・実績</small><b>${esc(g.live_scale||'未確認')}</b></div><div class="detail" style="grid-column:1/-1"><small>評価根拠</small><b>${esc(g.tier_reason||'未評価')}</b></div></div><h3>OFFICIAL LINKS</h3><div class="links">${links.map(([n,u])=>u?`<a class="linkBtn" target="_blank" rel="noopener" href="${esc(u)}"><span>${n}</span><span>↗</span></a>`:`<div class="linkOff"><span>${n}</span><span>未確認</span></div>`).join('')}</div><h3>MEMBERS <small>${members.length}</small></h3><div class="members">${members.length?members.map(memberCard).join(''):'<div class="empty">メンバー情報を再監査中</div>'}</div><h3>VERIFICATION</h3><div class="method">状態：<b>${esc(g.verification_status||'verified')}</b><br>最終確認：${esc(g.last_verified||DATA.as_of)}<br>${esc(g.verification_note||'')}</div><h3>SOURCES</h3><div class="sources">${(g.sources||[]).map(u=>`<a target="_blank" rel="noopener" href="${esc(u)}">${esc(u)}</a>`).join('')||'未確認'}</div>`;$('#innerClose').onclick=closeDrawer;}
function memberCard(m){const links=[['X',m.x||m.x_url],['IG',m.instagram||m.instagram_url],['TikTok',m.tiktok||m.tiktok_url],['YT',m.youtube||m.youtube_url]].filter(x=>x[1]);return `<div class="member"><b>${esc(m.name)}</b><div class="memberLinks">${links.map(([n,u])=>`<a target="_blank" rel="noopener" href="${esc(u)}">${n} ↗</a>`).join('')||'<span style="font-size:9px;color:#91a5ad">SNS未確認</span>'}</div></div>`;}
function closeDrawer(){$('#drawer').classList.remove('open')}
boot().catch(err=>{
  console.error(err);
  const fatal=document.querySelector('#fatal');
  if(fatal) fatal.hidden=false;
  const map=document.querySelector('#tierMap');
  if(map) map.innerHTML='<div class="empty">データ読み込みエラー。data.json / hq56.json の配置を確認してください。</div>';
});
