IDOLMAP 本命復元版

GitHubで置き換える:
- index.html
- styles.css
- app.js

そのまま残す:
- data.json
- hq56.json

特徴:
- 最初のIDOLMAPの構成を復元
- 「令和アイドル戦国時代 1枚の地図に。」
- 全アイドル / 勢力図 / ランキング の3タブ
- Power × Growth の2軸マップ
- 300組の母体を directory / curated / groups 全形式から統合
- 高精度56組を上書き
- 既存44組と合わせHQ100
- 詳細ドロワーで公式SNS・所属・レーベル・現役メンバー・評価根拠を表示
